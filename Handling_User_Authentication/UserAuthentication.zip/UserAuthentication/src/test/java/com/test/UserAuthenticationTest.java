package com.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@DisplayName("UserAuthentication Test")
	public class UserAuthenticationTest {
		
	@Test
	@DisplayName("Valid Username and Password")
	public void testValidCredentials() {
	final UserAuthentication userAuth = new UserAuthentication(); 
	boolean isAuthenticated = userAuth.authenticate("jerry", "tom"); 
	System.out.println("Valid Username and Password : " + isAuthenticated);
	assertTrue(isAuthenticated);
	}
	
	@Test
	@DisplayName("Invalid Username or Password")
	public void testInvalidCredentials() {
	final UserAuthentication userAuth = new UserAuthentication();
	boolean isAuthenticated = userAuth.authenticate("tom", "jerry");
	System.out.println("Valid Username or Password : " + isAuthenticated);
	assertFalse(isAuthenticated);
	}
	
	
}
