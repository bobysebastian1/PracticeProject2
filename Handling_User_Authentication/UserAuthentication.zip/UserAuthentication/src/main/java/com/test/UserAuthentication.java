package com.test;

public class UserAuthentication {
		private static final String VALID_USERNAME = "jerry";
		private static final String VALID_PASSWORD = "tom";
		public boolean authenticate(String username, String password) {
		if (username == null || password == null) {
		throw new IllegalArgumentException("Username and password cannot be null");
		}
		return username.equals(VALID_USERNAME) && password.equals(VALID_PASSWORD);
		}
		
}
