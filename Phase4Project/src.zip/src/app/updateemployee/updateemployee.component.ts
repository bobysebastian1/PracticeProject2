import { Component,OnInit } from '@angular/core';
import { EmployeeserviceService } from '../employeeservice.service';
import { Employee } from '../employee';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updateemployee',
  templateUrl: './updateemployee.component.html',
  styleUrls: ['./updateemployee.component.css']
})
export class UpdateemployeeComponent implements OnInit {

  constructor(private empserv:EmployeeserviceService, private router:ActivatedRoute, private router1:Router) {}

  id:number;
  emp:Employee;
  ngOnInit(): void {
    this.UpdateEmployee;
      
  }

  UpdateEmployee(id:number) {
    this.id = this.router.snapshot.params['id'];
    alert(this.id);
    this.emp=new Employee();
    this.empserv.GetOneEmployeeDetails(this.id).subscribe(data=>{
      console.log(data);
      this.emp=data;
    });
  }

}

