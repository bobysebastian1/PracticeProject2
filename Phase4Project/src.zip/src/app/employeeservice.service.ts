import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {

  constructor(private httpClient:HttpClient) { }

  private ApiUrl = "http://localhost:3000/employees";

    GetAllEmployeeDetails(){
    return this.httpClient.get<Employee[]>(this.ApiUrl);
    
    }

    AddNewEmployeeDetails(employee:Employee): Observable<Object>{
      return this.httpClient.post(`${this.ApiUrl}` , employee);
    
    }

    GetOneEmployeeDetails(id:number): Observable<Employee>{
      return this.httpClient.get<Employee>(`${this.ApiUrl}/${id}`);
      
    }

    DeleteEmployeeDetails(id:number): Observable<Object>{
      return this.httpClient.delete(`${this.ApiUrl}/${id}`);
      
    }

    UpdateEmployeeDetails(id:number, emp:Employee): Observable<Object>{
      return this.httpClient.put(`${this.ApiUrl}/${id}`,emp);
      
    }
    
  }
