import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ViewallComponent } from './viewall/viewall.component';
import { NewemployeeComponent } from './newemployee/newemployee.component';
import { ViewemployeeComponent } from './viewemployee/viewemployee.component';
import { UpdateemployeeComponent } from './updateemployee/updateemployee.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path:"",component:LoginComponent},
  {path:"home",component:HomeComponent},
  {path:"viewall",component:ViewallComponent},
  {path:"new",component:NewemployeeComponent},
  {path:"viewone/:id",component:ViewemployeeComponent},
  {path:"update/:id",component:UpdateemployeeComponent},
  {path:"login",component:LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
