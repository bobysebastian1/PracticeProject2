import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email:string="";
  password:number;

  constructor(private router:Router) {}

  ngOnInit(): void {
      
  }

  login(frm:any) {
    if(frm.valid){
    if(this.email === "admin@gmail.com" && this.password === 123)
    {
      this.router.navigate (['/home']);
    }
    else{
      this.router.navigate (['/home']);
    }
  }
  }
}
