import { Component,OnInit } from '@angular/core';
import { EmployeeserviceService } from '../employeeservice.service';
import { Employee } from '../employee';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-newemployee',
  templateUrl: './newemployee.component.html',
  styleUrls: ['./newemployee.component.css']
})
export class NewemployeeComponent implements OnInit {

  emp:Employee = new Employee();

  constructor(private empserv:EmployeeserviceService) {}

  ngOnInit(): void {
      this.AddNewEmployee;
  }

  
  AddNewEmployee(frm:any){
    this.empserv.AddNewEmployeeDetails(this.emp).subscribe(data=>{
      if(frm.valid){
      console.log(data);
      alert("New Employee Added Successfully...")
      }
      else{
        {
          alert("Invalid Data")
        }
      }
    });
  
  }

}
