import { Component,OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeserviceService } from '../employeeservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewall',
  templateUrl: './viewall.component.html',
  styleUrls: ['./viewall.component.css']
})
export class ViewallComponent implements OnInit {

 
  empinfo : Employee[];

  constructor(private empserv:EmployeeserviceService, private router:Router) {}

  ngOnInit(): void {
      this.GetEmpDetails();
  }
 
  GetEmpDetails(){
  this.empserv.GetAllEmployeeDetails().subscribe(data=>{
    console.log(data);
    this.empinfo=data;
  });

}

  GetOneEmpDetails(id:number){
    this.router.navigate(['viewone',id]);
  }


}