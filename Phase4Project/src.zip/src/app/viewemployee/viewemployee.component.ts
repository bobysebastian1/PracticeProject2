import { Component,OnInit } from '@angular/core';
import { EmployeeserviceService } from '../employeeservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';

@Component({
  selector: 'app-viewemployee',
  templateUrl: './viewemployee.component.html',
  styleUrls: ['./viewemployee.component.css']
})
export class ViewemployeeComponent implements OnInit {

  constructor(private empserv:EmployeeserviceService, private router:ActivatedRoute, private router1:Router){}

  id:number;
  emp:Employee;
  ngOnInit(): void {
    this.ViewOneEmployee();
    this.DeleteEmployeeInfo;
    this.UpdateEmployeeInfo;  
  }

  ViewOneEmployee(){
  this.id = this.router.snapshot.params['id'];
    this.emp=new Employee();
    this.empserv.GetOneEmployeeDetails(this.id).subscribe(data=>{
      console.log(data);
      this.emp=data;
    });
  }

  DeleteEmployeeInfo(id:number){
    this.empserv.DeleteEmployeeDetails(id).subscribe(data=>{
      alert("Deleted Successfully...")
    });

  }

  UpdateEmployeeInfo(id:number){
    this.router1.navigate(['update',id]);
  }

  }




