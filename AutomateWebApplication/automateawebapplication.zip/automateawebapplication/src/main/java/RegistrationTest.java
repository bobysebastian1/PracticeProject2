import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class RegistrationTest {
    public static void main(String[] args) throws Exception {
        WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("file:///E:/WebSites/Data%20Collection.html");

        //Get the registration form elements
        WebElement Name = driver.findElement(By.id("name"));
        WebElement Address = driver.findElement(By.id("addr"));
        WebElement Email = driver.findElement(By.id("email"));
        WebElement Password = driver.findElement(By.id("pass"));
        WebElement Telephone = driver.findElement(By.id("tel"));
        WebElement Course = driver.findElement(By.id("course"));
        WebElement Submit = driver.findElement(By.id("submit"));


        // Filling the registration form
        Name.sendKeys("Anugraha");
		System.out.println("Name : " + Name.getAttribute("value"));
		Thread.sleep(3000);
        Address.sendKeys("S22,KL,India");
        System.out.println("Address : " + Address.getAttribute("value"));
		Thread.sleep(3000);
        Email.sendKeys("anugraha.ek@gmail.com");
        System.out.println("EMail : " + Email.getAttribute("value"));
		Thread.sleep(3000);
        Telephone.sendKeys("9876543210");
        System.out.println("Phone No : " + Telephone.getAttribute("value"));
		Thread.sleep(3000);
        Password.sendKeys("anug.ek@123");
        System.out.println("Password : " + Password.getAttribute("value"));
		Thread.sleep(3000);
        Course.sendKeys("BBA");
        System.out.println("Course : " + Course.getAttribute("value"));
		Thread.sleep(3000);
        
        
        // Submit
        Submit.click();

        // Wait for successful registration verification
        boolean isRegistrationSuccessful = IsSuccessfulRegistration(driver);
        if (isRegistrationSuccessful) {
            System.out.println("Registration successful!!!");
        } else {
            System.out.println("Registration failed...");
        }

        // Close
        driver.quit();
    }

    private static boolean IsSuccessfulRegistration(WebDriver driver) {
        // Return true if login is successful, false otherwise
        return true;
    }
}
