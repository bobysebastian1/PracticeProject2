import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginTest {
    public static void main(String[] args) throws Exception {
        WebDriver driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get("file:///E:/WebSites/login.html");

        WebElement Email = driver.findElement(By.id("email"));
        WebElement Password = driver.findElement(By.id("pass"));
        WebElement Submit = driver.findElement(By.id("submit"));

        Email.sendKeys("augraha.ek@example.com");
        System.out.println("EMail : " + Email.getAttribute("value"));
		Thread.sleep(3000);
        Password.sendKeys("arugraha.ek@123");
        System.out.println("Password : " + Password.getAttribute("value"));
		Thread.sleep(3000);

        //Submit
        Submit.click();


        boolean isLoggedIn = verifyLogin(driver);
        if (isLoggedIn) {
            System.out.println("Login successful!!!");
        } else {
            System.out.println("Login failed...");
        }

        // Close
        driver.quit();
    }

    private static boolean verifyLogin(WebDriver driver) {
        // Return true if login is successful, false otherwise
        return true;
    }
}
