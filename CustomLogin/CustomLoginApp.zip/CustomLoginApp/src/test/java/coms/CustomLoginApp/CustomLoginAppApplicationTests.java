package coms.CustomLoginApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomLoginAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
