package com.tests;


import java.time.Duration;
import java.time.Instant;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.openqa.selenium.Dimension;

public class AutomateWebApp {
				
				WebDriver driver ;
				JavascriptExecutor js ;
				
				@Test
				public void Flipkart() throws InterruptedException {
					
					driver = new ChromeDriver();
					driver.manage().window().maximize();
					
					driver.manage().timeouts();
					
					Instant startTime = Instant.now();
					System.out.println("Page Load Start Time : " +startTime.toString());
					
			    	driver.get("https://www.flipkart.com/");
					
					Instant endTime = Instant.now();
					System.out.println("Page Load End Time : " +endTime.toString());
					
					Duration duration = Duration.between(startTime, endTime);
					System.out.println("Page Load Duration Time is : " + ((duration.toMillis())/1000) + " Seconds");
					
					System.out.println("Page URL is : " +driver.getCurrentUrl());
					System.out.println("-----------------------------------------");
					
					Thread.sleep(3000);
		    
			    }
				
				@Test(dependsOnMethods="Flipkart")
				public void FlipkartClearLogin() throws Exception {
					
					Actions actions = new Actions(driver);
					
					Action Escape = actions.sendKeys(Keys.ESCAPE).build();
					
					Escape.perform();
					
					System.out.println("Current Page Title is : " +driver.getTitle());
					System.out.println("-----------------------------------------");
	
					Thread.sleep(3000);
				
				}
				

				@Test(dependsOnMethods="FlipkartClearLogin")
				public void FlipkartSearch() throws Exception {
					
					WebElement Search = driver.findElement(By.name("q"));
			    	WebElement Enter = driver.findElement(By.className("L0Z3Pu"));
					Search.sendKeys("iPhone 13");
					Enter.click();
					Thread.sleep(6000);
					
					System.out.println("Current Page Title is : " +driver.getTitle());
					System.out.println("-----------------------------------------");
					
				}
				
				@Test(dependsOnMethods="FlipkartSearch")
				public void FlipkartSearchScrollDown() throws InterruptedException {
					
					js = (JavascriptExecutor) driver;
					js.executeScript("window.scrollBy(0,1000)");
					Thread.sleep(6000);
					js.executeScript("window.scrollBy(1000,2000)");
					Thread.sleep(6000);
					js.executeScript("window.scrollBy(2000,3000)");
					Thread.sleep(6000);
					js.executeScript("window.scrollBy(3000,4000)");
					Thread.sleep(6000);
					System.out.println("Current Page URL : " +driver.getCurrentUrl());
					System.out.println("-----------------------------------------");

					
				}
				
				@Test(dependsOnMethods="FlipkartSearchScrollDown")
				public void FlipkartIsAtBottom() throws InterruptedException {
					
					js = (JavascriptExecutor) driver;
					WebElement Footer = driver.findElement(By.className("_3voSl0"));
					Thread.sleep(6000);
					
					if(Footer.isDisplayed()) {
						System.out.println("The Page is at Bottom");
					}
					else {
						System.out.println("The Page is not at Bottom");

					}
					
					System.out.println("-----------------------------------------");
					
				}
				
				@Test(dependsOnMethods="FlipkartIsAtBottom")
				public void FlipkartBackToTop() throws InterruptedException {
					
					String BottomPageSource = driver.getPageSource();
					js = (JavascriptExecutor) driver;
					WebElement Enter = driver.findElement(By.className("_3ZKfA2"));
					Enter.click();
					Thread.sleep(6000);
					String TopPageSource = driver.getPageSource();
					
					if(BottomPageSource == TopPageSource) {
						System.out.println("The Page is Still at Bottom");
					}
					else {
						System.out.println("The Page is gone Back to the Top");
					}
					
					System.out.println("-----------------------------------------");
					
				}
				
				@Test(dependsOnMethods="FlipkartBackToTop")
				public void FlipkartScrollDownRefresh() throws InterruptedException {
					
					js = (JavascriptExecutor) driver;
					js.executeScript("window.scrollBy(0,500)");
					Thread.sleep(6000);
					String FirstPageSource = driver.getPageSource();
					js.executeScript("window.scrollBy(500,1000)");
					Thread.sleep(6000);
					String SecondPageSource = driver.getPageSource();
					
					if(FirstPageSource == SecondPageSource) {
						System.out.println("The Page is Not Refreshed while Scrolling Down");
					}
					else {
						System.out.println("The Page is Refreshed while Scrolling Down");
					}
					
					System.out.println("-----------------------------------------");


					
				}
				
				@Test(dependsOnMethods="FlipkartScrollDownRefresh")
				public void FlipkartSearchClick() throws InterruptedException {
					
					Thread.sleep(6000);
					WebElement Enter = driver.findElement(By.className("MIXNux"));
					Enter.click();
					Thread.sleep(6000);
					
					driver.quit();
					
					
				}
				
				@Test(dependsOnMethods="FlipkartSearchClick")
				public void FlipkartTestWithFirefox() throws InterruptedException {
					
					driver = new FirefoxDriver();
					driver.manage().window().maximize();
					
					driver.manage().timeouts();
					
					Instant startTime = Instant.now();
					System.out.println("Page Load Start Time : " +startTime.toString());
					
			    	driver.get("https://www.flipkart.com/");
					
					Instant endTime = Instant.now();
					System.out.println("Page Load End Time : " +endTime.toString());
					
					Duration duration = Duration.between(startTime, endTime);
					System.out.println("Page Load Duration Time is : " + ((duration.toMillis())/1000) + " Seconds");
					
					System.out.println("Page URL is : " +driver.getCurrentUrl());
					System.out.println("-----------------------------------------");
					
					Thread.sleep(3000);
		    
			    }
				
				@Test(dependsOnMethods="FlipkartTestWithFirefox")
				public void FlipkartScreenResolution() throws InterruptedException {
				
					Dimension dimension = new Dimension(1520, 780);
					driver.manage().window().setSize(dimension);
					
					System.out.println("The Screen Dimension : "+dimension);
					
					System.out.println("-----------------------------------------");
					
					Thread.sleep(3000);
					
				}

				
				@BeforeTest
				public void BeforeTest() throws InterruptedException {
					
					System.out.println("The Flipkart Test is Started");
					
					System.out.println("-----------------------------------------");
				
				}
				
				@AfterTest
				public void ClearTest() throws InterruptedException {
					
					System.out.println("The Flipkart Test is Completed");
					
					System.out.println("-----------------------------------------");
					
					driver.quit();
	
				}
				
				
				
}
