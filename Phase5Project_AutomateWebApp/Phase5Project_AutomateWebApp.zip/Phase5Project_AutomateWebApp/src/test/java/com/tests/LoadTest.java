package com.tests;

import java.time.Duration;
import java.time.Instant;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoadTest {
		
		WebDriver driver ;
		JavascriptExecutor js ;
		
		@Test(groups="Chrome")
		public void Flipkart() throws InterruptedException {
			
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			
			driver.manage().timeouts();
			
			System.out.println("-----------------------------------------");
			Instant startTime = Instant.now();
			System.out.println("Page Load Start Time : " +startTime.toString());
			
	    	driver.get("https://www.flipkart.com/");
			
			Instant endTime = Instant.now();
			System.out.println("Page Load End Time : " +endTime.toString());
			
			Duration duration = Duration.between(startTime, endTime);
			System.out.println("Page Load Duration Time is : " + ((duration.toMillis())/1000) + " Seconds");
			System.out.println("-----------------------------------------");
			Thread.sleep(3000);
    
	    }
		
		
		@Test(dependsOnMethods="Flipkart")
		public void FlipkartSearch() throws InterruptedException {
			
	    	WebElement Search = driver.findElement(By.name("q"));
	    	WebElement Enter = driver.findElement(By.className("L0Z3Pu"));
			Search.sendKeys("iPhone 13");
			Enter.click();
			Thread.sleep(6000);
			
		}
		
		@Test(dependsOnMethods="FlipkartSearch")
		public void FlipkartSearchScrollDown() throws InterruptedException {
			
			js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0,document.body.sccrollHeight)");
			Thread.sleep(6000);
			driver.quit();
			
		}

}
