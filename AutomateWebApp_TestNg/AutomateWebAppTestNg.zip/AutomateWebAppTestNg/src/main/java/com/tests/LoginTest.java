package com.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class LoginTest {
	
	public static void main(String[] args) throws Exception {
	}
		WebDriver driver;
	    @Test(groups="Chrome")
	    public void LoadingPage() throws InterruptedException {
	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("file:///E:/WebSites/login2.html");
	        Thread.sleep(2000);
    
	    }
	    
	    @Test(dependsOnMethods="LoadingPage")
	    public void Login() throws InterruptedException {
	    	driver.findElement(By.id("email")).sendKeys("johny@gmail.com");
	    	System.out.println("EMail : " + driver.findElement(By.id("email")).getAttribute("value"));
	    	Thread.sleep(2000);
	        driver.findElement(By.id("pass")).sendKeys("johny@123");
	        System.out.println("Password : " + driver.findElement(By.id("pass")).getAttribute("value"));
	        Thread.sleep(2000);
	        driver.findElement(By.id("submit")).click();
	        Thread.sleep(2000);
	        driver.quit();
	       
    
		}
	    

	    

}
