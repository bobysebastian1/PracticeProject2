package com.hibernate.services;
import java.io.Serializable;
import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.hibernate.dbconn.HibernateConfig;
import com.hibernate.model.Product;
public class ProductOperations {
	private SessionFactory sfactory = null;
	public ProductOperations()
	{
		sfactory = HibernateConfig.getSessionFactory();
	}
	
	public String AddNewProduct(Product std)
	{
		String result = "Error";
		Session sObj = sfactory.openSession();
		Transaction trns = sObj.beginTransaction();
		Serializable s = sObj.save(std);
		trns.commit();
		
		if(s!=null)
			result =  "Success";
		
		return result;
	}
	
	public List<Product>  ShowAll()
	{
		Session sObj = sfactory.openSession();
		Query qry = sObj.createQuery("from Product");  // Student is a class
		List<Product>  sall = qry.list();
		return sall;
	}
	

}

